#!/usr/bin/env python3
"""Local macOS launcher: one Safari window with three ordered tabs, no browser popups."""
import argparse,json,subprocess,sys
from pathlib import Path
from urllib.parse import urlencode

def urls(name,city,address):
    if not name.strip() or not city.strip():raise ValueError('Укажите название и город')
    if len(name)>120 or len(city)>100 or len(address)>250:raise ValueError('Слишком длинное название, город или адрес')
    query=urlencode({'clinicName':name.strip(),'city':city.strip(),'address':address.strip()})
    root='https://timofeyalekperov.github.io/dental-studio-demo/#'
    return [root+route+'?'+query for route in ['/','/booking','/recording-crm']]

def safari_script(links):
    literal=lambda text:json.dumps(text,ensure_ascii=False)
    return '\n'.join(['tell application "Safari"','activate','make new document with properties {URL:'+literal(links[0])+'}','tell front window','make new tab at end of tabs with properties {URL:'+literal(links[1])+'}','make new tab at end of tabs with properties {URL:'+literal(links[2])+'}','set current tab to tab 1','end tell','end tell'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');args=parser.parse_args()
    if args.check:
        links=urls('Клиника "Улыбка"','Казань','улица Мира, 1');assert len(links)==3 and '%22' in links[0];assert '/booking?' in links[1] and '/recording-crm?' in links[2];print('Launcher URL and tab order checks passed');return
    config=Path(__file__).with_name('.launcher-clinic.json')
    try:last=json.loads(config.read_text())
    except (OSError,ValueError):last={'name':'Эмаль','city':'Екатеринбург','address':'улица Мира'}
    print('Подготовка трёх вкладок Safari. Enter — оставить прежнее значение.\n')
    values={key:input(f'{label} [{last.get(key, "")}]: ').strip() or last.get(key,'') for key,label in [('name','Название клиники'),('city','Город'),('address','Адрес')]}
    links=urls(**values);config.write_text(json.dumps(values,ensure_ascii=False,indent=2))
    subprocess.run(['osascript','-e',safari_script(links)],check=True)
    print('\nОткрыто новое окно Safari: сайт → запись → CRM. Можно снимать.')

if __name__=='__main__':
    try:main()
    except (ValueError,subprocess.CalledProcessError) as error:print('Не удалось открыть вкладки:',error);input('Нажмите Enter для выхода.');sys.exit(1)

﻿$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$configPath = Join-Path $PSScriptRoot 'clinic.json'
$values = @{ name = 'Эмаль'; city = 'Екатеринбург'; address = 'улица Мира' }
if (Test-Path $configPath) {
    try {
        $saved = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($key in @('name', 'city', 'address')) { if ($saved.$key) { $values[$key] = [string]$saved.$key } }
    } catch { Write-Host 'Не удалось прочитать прежние значения. Введите данные заново.' }
}
Write-Host 'Запуск сайта, записи и CRM. Enter — оставить прежнее значение.'
foreach ($field in @(@('name','Название клиники'), @('city','Город'), @('address','Адрес'))) {
    $answer = Read-Host "$($field[1]) [$($values[$field[0]])]"
    if (-not [string]::IsNullOrWhiteSpace($answer)) { $values[$field[0]] = $answer.Trim() }
}
if ($values.name.Length -gt 120 -or $values.city.Length -gt 100 -or $values.address.Length -gt 250) {
    throw 'Слишком длинное название (до 120 символов), город (до 100) или адрес (до 250).'
}
$values | ConvertTo-Json | Set-Content $configPath -Encoding UTF8
$query = 'clinicName=' + [Uri]::EscapeDataString($values.name) + '&city=' + [Uri]::EscapeDataString($values.city) + '&address=' + [Uri]::EscapeDataString($values.address)
$root = 'https://timofeyalekperov.github.io/dental-studio-demo/#'
$urls = @($root + '/?' + $query; $root + '/booking?' + $query; $root + '/recording-crm?' + $query)
# Launch all URLs through one Chromium process; site popup restrictions do not apply.
$candidates = @()
if (${env:ProgramFiles(x86)}) { $candidates += Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe' }
if ($env:ProgramFiles) {
    $candidates += Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'
    $candidates += Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'
}
if ($env:LOCALAPPDATA) {
    $candidates += Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'
    $candidates += Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'
}
$browser = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) { throw 'Не найден Microsoft Edge или Google Chrome. Установите один из них и повторите запуск.' }
$arguments = @('--new-window') + @($urls | ForEach-Object { '"' + $_ + '"' })
Start-Process -FilePath $browser -ArgumentList $arguments
Write-Host 'Открыто новое окно: сайт, запись, CRM. Данные сохранены для следующего запуска.'
